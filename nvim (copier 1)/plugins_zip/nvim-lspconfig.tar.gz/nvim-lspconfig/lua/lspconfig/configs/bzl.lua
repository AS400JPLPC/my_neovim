-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- This config is DEPRECATED.
-- Use the configs in `lsp/` instead (requires Nvim 0.11).
--
-- ALL configs in `lua/lspconfig/configs/` will be DELETED.
-- They exist only to support Nvim 0.10 or older.
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
local util = require 'lspconfig.util'

return {
  default_config = {
    cmd = { 'bzl', 'lsp', 'serve' },
    filetypes = { 'bzl' },
    -- https://docs.bazel.build/versions/5.4.1/build-ref.html#workspace
    root_dir = util.root_pattern('WORKSPACE', 'WORKSPACE.bazel'),
  },
  docs = {
    description = [[
https://bzl.io/

https://docs.stack.build/docs/cli/installation

https://docs.stack.build/docs/vscode/starlark-language-server
]],
  },
}
